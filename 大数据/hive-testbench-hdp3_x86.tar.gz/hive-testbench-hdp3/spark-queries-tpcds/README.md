These are the full 99 TPC-DS queries from Apache Spark 2.2.

- https://github.com/apache/spark/tree/master/sql/core/src/test/resources/tpcds
