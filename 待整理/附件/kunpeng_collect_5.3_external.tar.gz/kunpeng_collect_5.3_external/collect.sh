#!/bin/bash

trap 'sig_handler' INT
sig_handler(){
    log INFO "Dectect Ctrl+C, close collect..."
    kill -9 $(ps -ef|grep -E "nmon_|nmonchart_"|awk '{print $2}')
    kill -9 $(ps -ef|grep "bash collect.sh"|awk '{print $2}')
    kill -9 $(ps -ef|grep LoadCollectAnalysis_|awk '{print $2}')
    kill -9 $(ps -ef | grep -E "cdevserver /dev/net_cdev 8880|tcpserver 127.0.0.1 8881 127.0.0.1 8880 40443" | awk '{print $2}') &>/dev/null
    kill -9 $(ps -ef|grep BIOSTools |awk '{print $2}')
    for ip in $(cat ${HOME}/ip_passwd_list |grep -vE ^"#|^$"|grep [a-zA-Z0-9] |awk '{print $1}') ; do 
        passwd="$(cat ${HOME}/ip_passwd_list |grep ${ip}|awk '{print $NF}'|sed -n 1p)"
        ssh_exec "root" "${passwd}" "${ip}" "kill -9 \$(ps -ef|grep -E \"bash collect.sh|nmon_|nmonchart_|LoadCollectAnalysis_|BIOSTools\"|awk '{print \$2}') " 
        ssh_exec "root" "${passwd}" "${ip}" "kill -9 \$(ps -ef | grep -E 'cdevserver /dev/net_cdev 8880|tcpserver 127.0.0.1 8881 127.0.0.1 8880 40443' | awk '{print \$2}')  " 
        ssh_exec "root" "${passwd}" "${ip}" "kill -9 \$(ps -ef|grep -E \"/tmp/collect_this/\"|awk '{print \$2}')"
        ssh_exec "root" "${passwd}" "${ip}" "rm -rf /tmp/collect_this/"
    done
    exit 1
}

# 公共函数
function log() {
    local time="$(date "+%Y-%m-%d %H:%M:%S")"
    local level="$1"
    shift
    if [ "$1" = "red" ] || [ "$1" = "green" ] || [ "$1" = "yellow" ]; then
        local color="$1"
        shift
    fi
    local content="$*"
    # 颜色内容处理
    case $color in
    red)
        local content_color="\e[31m${content}\e[0m"
        shift
        ;;
    green)
        local content_color="\e[32m${content}\e[0m"
        shift
        ;;
    yellow)
        local content_color="\e[33m${content}\e[0m"
        shift
        ;;
    *)
        local content_color="${content}"
        shift
        ;;
    esac
    # 级别识别和打印内容
    local print_string="$(printf "%s [%s][%s]: %-5s\n" "${time}" "${level}" "${LOCAL_IP}" "${content}")"
    local print_string_color="$(printf "%s [%s][%s]: %-5s\n" "${time}" "${level}" "${LOCAL_IP}" "${content_color}")"
    case $level in
    DEBUG | debug | ERROR | error | INFO | info | WARN | warn)
        printf "${print_string_color}\n"
        #printf "${print_string}\n" &>>${LOG_FILE_PATH} && return 0
        ;;
    print | PRINT)
        printf "${content_color}\n"
        #printf "${content}\n" &>>${LOG_FILE_PATH} && return 0
        ;;
    show | SHOW) printf "${print_string_color}\n" && return 0 ;;
    *) return 1 ;;
    esac
}



function help_info()
{
    printf "\nUsage:\n"
    printf " ${SCRIPT_NAME} -t [collect times] -p [pid]\n\n"
    printf "Options:\n"
    printf " %-15s %s\n"  "-p" "example: pid1,pid2"
    printf " %-15s %s\n"  "-t" "collect seconds, default 5"
    printf " %-15s %s\n"  "-k" "result dir keywords"
    printf " %-15s %s\n"  "-d" "set collecting conf file or some dirs, default "
    printf " %-15s %s\n"  "-K" "set process keywords, default , input multi with \":\""
    printf " %-15s %s\n"  "-s" "set collect type, default: all, support {basic_and_perf_info |micro_info | hardware_info| os_info | nmon_info}, input multi with \":\""
    printf " %-15s %s\n"  "-v" "show version info"
    printf " %-15s %s\n\n"  "-h" "show help info"
    printf " %-15s %s\n"  "Example1: " "bash ${SCRIPT_NAME} -t 5 -p \$(pidof mysql)"
    printf " %-15s %s\n"  "Example2: " "bash ${SCRIPT_NAME} -t 5 -k test -p \$(pidof observer),\$(pidof obproxy)"
    printf " %-15s %s\n"  "Example3: " "bash ${SCRIPT_NAME} -t 5 -d /etc/profile:/etc/sysctl.conf:/etc/my.cnf"
    printf " %-15s %s\n\n"  "Example4: " "bash ${SCRIPT_NAME} -t 5 -K observer:obproxy -s basic_info:nmon_info:os_info"
}

function get_input()
{
    while getopts ":p:t:k:d:K:s:vh" opt ; do
        case $opt in
            t) TIME="$OPTARG" ;;
            p) PID="$OPTARG" ;;
            k) RES_KEYWORDS="$OPTARG" ;;
            d) COLLECT_PATH="$OPTARG" ;;
            K) PROCESS_KEY="$OPTARG" ;;
            s) SUB_FUNCTION_INPUT="$OPTARG" ;;
            v) echo "${VERSION}" ; exit 0 ;;
            h) help_info ; exit 0 ;;
            ?) help_info ; exit 1 ;;
        esac
    done
}

function get_basic_info {
    if [ "$BASIC_PERF_INFO_FLAG" -eq 0 ] ; then return 0; fi 
    mkdir -p "${LOG_DIR_PATH}/basic_info$3$2"
    if [ -n "$2" ]; then
    	log INFO "Collect basic info with pid ${2}/${3#_} ..."
    else
        log INFO "Collect basic info..."
    fi	
    ${COLLECTLOAD_TOOL_EXEC} -t ${TIME} $1 $2 &>/dev/null
    # rm -rf ${HOME}/LoadCollectResult/*/*.data
    mv ${HOME}/LoadCollectResult/*/* "${LOG_DIR_PATH}/basic_info$3$2" &>/dev/null
    rm -rf "${HOME}/LoadCollectResult"
}

function get_micro_info {
    if [ "$MICRON_INFO_FLAG" -eq 0 ] ; then return 0; fi 
    if [ -n "$2" ]; then
    	log INFO "Collect micron info with pid ${2}/${3#_} ..."
    else
        log INFO "Collect micron info..."
    fi
    if uname -m|grep x86 &>/dev/null; then
	return 0;
    fi
    # local times=$(expr ${TIME} / 5)
    # if [ "$TIME" -gt 5 ] ; then
    #     local times=1
    # fi
    ${PERF_TOOL_EXEC} -i 1 -t ${TIME} $1 $2 &>/dev/null
    mkdir -p "${LOG_DIR_PATH}/micro_info$3$2"
    mv ${HOME}/perf_results/*/* "${LOG_DIR_PATH}/micro_info$3$2" &>/dev/null
    rm -rf "${HOME}/perf_results"
}

function get_hardware_info {
    if [ "$HARDWARE_INFO_FLAG" -eq 0 ] ; then return 0; fi 
    log INFO "Collect hardware info..."
    if uname -m|grep x86 &>/dev/null; then
	return 0;
    fi
    local hard_log_path="${LOG_DIR_PATH}/hardware_info"
    mkdir -p "${hard_log_path}"
    BIOSTools -c "${hard_log_path}" &>/dev/null
    kill -9 $(ps -ef | grep -E "cdevserver /dev/net_cdev 8880|tcpserver 127.0.0.1 8881 127.0.0.1 8880 40443" | awk '{print $2}') &>/dev/null
}

function get_os_info {
    if [ "$OS_INFO_FLGA" -eq 0 ] ; then return 0; fi 
    log INFO "Collect os info..."
    mkdir -p "${LOG_DIR_PATH}/os_info"
    bash ${OS_CHECK_TOOL_EXEC} "${LOG_DIR_PATH}/os_info" 2>/dev/null
    mv ${HOME}/env*json "${LOG_DIR_PATH}/os_info" &>/dev/null
    rm -rf "${HOME}/env*json"
    rm -rf "${HOME}/.debug"
    # mkdir -p "${LOG_DIR_PATH}/os_info/extra"
    # bash ${EXTRA_TOOL_EXEC} "${LOG_DIR_PATH}/os_info/extra" &>/dev/null

}

function get_nmon_info()
{
    if [ "$1" = "start" ]; then
        mkdir -p ${LOG_DIR_PATH}/nmon
        pkill -9 nmon_$(uname -m)
        log INFO "Begin nmon collecting..."
        ${NMON_TOOL_EXEC} -F ${LOG_DIR_PATH}/nmon/collect_$(hostname).nmon -s 1 -c 3600
    fi
    if [ "$1" = "stop" ]; then
        start_time="$2"
        end_time="$3"
        pkill -9 nmon_$(uname -m)
        mv ${LOG_DIR_PATH}/nmon/collect_$(hostname).nmon ${LOG_DIR_PATH}/nmon/$(hostname)_${start_time}_${end_time}.nmon
        # log INFO "Transfer nmon to html..."
        # if ! which ksh &>/dev/null ;  then
        #     log INFO "Try to install ksh..."
        #     yum instll -y ksh
        # fi
        # ${NMONCHART_TOOL_EXEC} ${LOG_DIR_PATH}/nmon/collect_$(hostname).nmon ${LOG_DIR_PATH}/nmon/$(hostname)_${start_time}_${end_time}_nmon.html
    fi
}

function nmon_transfer_html()
{
    install_ksh=0
    if ! which ksh &>/dev/null; then
        log INFO "ksh is not installed, compiler ksh, it'll take a few minutes..."
        bash "${kSH_INSTALL_SCRIPT}" "${HOME}/scripts" &>/dev/null
        install_ksh=1
    fi
    log INFO "Transfer nmon to html..."
    for nmon_file in $(find ${LOG_DIR_PATH} -name *.nmon); do
        ${NMONCHART_TOOL_EXEC} ${nmon_file} ${nmon_file}.html
    done
    if [ "$install_ksh" -eq 1 ]; then
        unlink /usr/bin/ksh
    fi
}


function prerun()
{
    export LANG=en_US.UTF-8
    HOME="$(cd $(dirname $0); pwd)"
    export PATH=${HOME}/bin:${PATH}
    if [ -n "${HOME}/ip_passwd_list" ] && cat ${HOME}/ip_passwd_list 2>/dev/null |grep -vE ^"#|^$"|grep [a-zA-Z0-9] &>/dev/null; then
        EXPECT_INSTALL_SCRIPT="${HOME}/tools/expect/build.sh"
        SSHPASS_INSTALL_SCRIPT="${HOME}/tools/sshpass/build.sh"
        NOKEY_SCRIPT="${HOME}/scripts/nokey.sh"
        if ! which expect &>/dev/null && ! yum install expect -y &>/dev/null; then
            log INFO "Compile expect binary..."
            if ! bash ${EXPECT_INSTALL_SCRIPT} >/dev/null ;then
                log ERROR "Compile expect failed"
                exit 1
            fi
        fi
    fi
    kSH_INSTALL_SCRIPT="${HOME}/tools/ksh/build.sh"
    export LD_LIBRARY_PATH=${HOME}/lib:${LD_LIBRARY_PATH}
    chmod 755 ${HOME}/bin/* ${HOME}/scripts
    SCRIPT_NAME="$0"
    PROCESS_KEY=("")
    TIME=5
    VERSION="V2.0 20241207"
    LOCAL_IP="$(ip a|grep -E "[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}\.[0-9]{1,3}"|grep -v 127.0.0.1|grep inet|awk -F '/' '{print $1}'|awk '{print $NF}'|sed -n 1p)"
    COLLECT_PATH=""
    local arch="$(arch)"
    COLLECTLOAD_TOOL_EXEC="${HOME}/bin/LoadCollectAnalysis_${arch}"
    PERF_TOOL_EXEC="${HOME}/bin/PerfTools_${arch}"
    HARDWARE_TOOL_EXEC="BIOSTools"
    if ! ldconfig -p |grep libncurses.so.5 &>/dev/null ; then
        ln -sf $(ldconfig -p |grep libncurses.so|sed -n 1p|awk '{print $NF}') ${HOME}/lib/libncurses.so.5
        ln -sf $(ldconfig -p |grep libtinfo.so|sed -n 1p|awk '{print $NF}') ${HOME}/lib/libtinfo.so.5
    fi
    NMON_TOOL_EXEC="${HOME}/bin/nmon_${arch}"
    NMONCHART_TOOL_EXEC="${HOME}/bin/nmonchart_${arch}"
    OS_CHECK_TOOL_EXEC="${HOME}/scripts/os_info.sh"
    EXTRA_TOOL_EXEC="${HOME}/scripts/extra_info_collect.sh"
    BIOSTOOLS_RPM="$(ls ${HOME}/rpms/BIOSTools*|sed -n '1p')"
    PID=""
    RES_KEYWORDS=""
    REMOTE_FLAG=0
    PROCESS_KEY=""
    SUB_FUNCTION_INPUT=""
    BASIC_PERF_INFO_FLAG=1
    MICRON_INFO_FLAG=1
    HARDWARE_INFO_FLAG=1
    OS_INFO_FLGA=1
    NMON_FLAG=1
    get_input $@
    if [ -n "$SUB_FUNCTION_INPUT" ] ; then
        if ! echo "$SUB_FUNCTION_INPUT"  |grep basic_and_perf_info &>/dev/null ; then
            BASIC_PERF_INFO_FLAG=0
        fi
        if ! echo "$SUB_FUNCTION_INPUT"  |grep micro_info &>/dev/null ; then
            MICRON_INFO_FLAG=0
        fi
        if ! echo "$SUB_FUNCTION_INPUT"  |grep hardware_info &>/dev/null ; then
            HARDWARE_INFO_FLAG=0
        fi
        if ! echo "$SUB_FUNCTION_INPUT"  |grep os_info &>/dev/null ; then
            OS_INFO_FLGA=0
        fi
        if ! echo "$SUB_FUNCTION_INPUT"  |grep nmon_info &>/dev/null ; then
            NMON_FLAG=0
        fi
    fi
    if [ -z "$PID" ] && [ -n "$PROCESS_KEY" ]; then
        for pid in $(ps -ef|grep -E "$(echo $PROCESS_KEY|tr ':' '|')" |grep -v grep|grep -vw $$ |awk '{print $2}'); do
            if [ -z "$PID" ]; then
                PID="${pid}"
            else
                PID="${PID},${pid}"
            fi
        done
    fi

    LOG_DIR_PATH="${HOME}/results/$(date "+%Y-%m-%d-%H-%M-%S")"
    if [ -n "$RES_KEYWORDS" ] ; then
        LOG_DIR_PATH="${HOME}/results/$(date "+%Y-%m-%d-%H-%M-%S")_${RES_KEYWORDS}"
    fi
    mkdir -p "$LOG_DIR_PATH"
    post_biostools_flag=0
    if ! rpm -qa|grep $(ls rpms/ |sed 's!.rpm!!g') &>/dev/null; then
        rpm -e $(rpm -qa |grep BIOSTools|sed -n '1p') &>/dev/null
        post_biostools_flag="$?"
    fi
    rpm -ivh ${BIOSTOOLS_RPM} &>/dev/null
    cd ${HOME}
}

#ssh_exec函数：ssh到linux后执行命令
#传入参数： user(ssh的用户名)
#          passwd(ssh的密码)
#          ip(ssh的ip地址)
#          expect_cmd(ssh后执行的命令)
ssh_exec() {
    local user="$1"
    shift
    local passwd="$1"
    shift
    local ip="$1"
    shift
    local expect_cmd="$*"
    expect <<-EOF
        set timeout 600
        spawn ssh  ${user}@${ip} "${expect_cmd}"
        expect {
                "*yes/no*" {send "yes\r";exp_continue}
                "*password*" {send "$passwd\r"}
        }
        expect eof
EOF
}

#scp_exec函数：scp文件到Linux
#传入参数： user(ssh的用户名)
#          passwd(ssh的密码)
#          ip(ssh的ip地址)
#          mode : 0: 从本地拷贝文件到远端Linux. 1：从远端Linux拷贝文件到本地
#          remote_path: 远端路径
#          local_path： 本地路径
scp_exec() {
    local user="$1"
    shift
    local passwd="$1"
    shift
    local ip="$1"
    shift
    local mode="$1"
    shift
    local remote_path="$1"
    shift
    local local_path="$*"
    shift
    local cmd=""
    pwd
    if [ "$mode" -eq 0 ]; then
        cmd="scp -r ${local_path} ${user}@${ip}:${remote_path}"
    else
        cmd="scp -r ${user}@${ip}:${remote_path} ${local_path}"
    fi
    expect <<-EOF
        set timeout 600
        spawn $cmd
        expect {
                "*yes/no*" {send "yes\r";exp_continue}
                "*password*" {send "$passwd\r"}
        }
        expect eof
EOF
}

function run_remote()
{
    for ip in $(cat ${HOME}/ip_passwd_list 2>/dev/null |grep -vE ^"#|^$"|grep [a-zA-Z0-9] |awk '{print $1}') ; do 
        log INFO "Collect Info on host: ${ip}"
        passwd="$(cat ${HOME}/ip_passwd_list |grep ${ip}|awk '{print $NF}' | sed -n 1p)"
        cd ${HOME}
        ssh_exec "root" "${passwd}" "${ip}" "rm -rf /tmp/collect_this && mkdir -p /tmp/collect_this" 
        scp_exec "root" "${passwd}" "${ip}" 0 /tmp/collect_this "$(ls |grep -vE "result|ip_passwd_list|tools"|tr  "\n" " " )"  
        ssh_exec "root" "${passwd}" "${ip}" "cd /tmp/collect_this && bash collect.sh $@" &
    done
    wait
    for ip in $(cat ${HOME}/ip_passwd_list 2>/dev/null |grep -vE ^"#|^$"|grep [a-zA-Z0-9] |awk '{print $1}') ; do 
        passwd="$(cat ${HOME}/ip_passwd_list |grep ${ip}|awk '{print $NF}' | sed -n 1p)"
        mkdir -p ${LOG_DIR_PATH}/${ip}
        log INFO "Copy collect result from ${ip}"
        scp_exec "root" "${passwd}" "${ip}" 1 "/tmp/collect_this/results/*/*" "${LOG_DIR_PATH}/${ip}"
        ssh_exec "root" "${passwd}" "${ip}" "rm -rf /tmp/collect_this"
    done
    wait
    nmon_transfer_html
}

function run()
{
    if [ -n "${HOME}/ip_passwd_list" ] && cat ${HOME}/ip_passwd_list 2>/dev/null |grep -vE ^"#|^$"|grep [a-zA-Z0-9] &>/dev/null; then
        run_remote $@
        return 0
    fi
    start_time="$(date +%Y-%m-%d-%H-%M-%S)"
    get_nmon_info start
    if [ -n "$PID" ];then
	    for pid in $(echo $PID|tr "," "\n"); do
        	get_micro_info -p $pid _$(cat /proc/$pid/comm)
            if dstat_$(uname -m) -h &>/dev/null ; then
                mkdir -p "${LOG_DIR_PATH}/basic_info_$(cat /proc/$pid/comm)${pid}"
                dstat_$(uname -m) -cmdnvgrp --vm  1 ${TIME} &> ${LOG_DIR_PATH}/basic_info_$(cat /proc/$pid/comm)${pid}/dstat.txt &
            fi
	    	get_basic_info -p $pid _$(cat /proc/$pid/comm)
	    done
    else
        get_micro_info
        if dstat_$(uname -m) -h &>/dev/null ; then
            mkdir -p ${LOG_DIR_PATH}/basic_info
            dstat_$(uname -m) -cmdnvgrp --vm  1 ${TIME} &> ${LOG_DIR_PATH}/basic_info/dstat.txt &
        fi
        get_basic_info
    fi
    get_os_info
    get_hardware_info
    wait
    if [ -n "$SUB_FUNCTION_INPUT" ] && [ "$SUB_FUNCTION_INPUT" = "nmon_info" ] ; then
        sleep ${TIME}
    fi
    end_time="$(date +%Y-%m-%d-%H-%M-%S)"
    get_nmon_info stop $start_time $end_time
    if [ -n "$COLLECT_PATH" ] ; then
        log INFO "config file collecting..."
        mkdir -p ${LOG_DIR_PATH}/collect_file
        for path in $(echo $COLLECT_PATH|tr ":" " "); do
            log INFO "Collect file or dir: ${path}"
            mkdir -p ${LOG_DIR_PATH}/collect_file/$(dirname $path)
            yes |cp -a "$path"  ${LOG_DIR_PATH}/collect_file/$(dirname $path) &>/dev/null
        done
    fi
    if [ ! -s "${HOME}/ip_passwd_list" ] ; then
        return 0
    fi
    nmon_transfer_html
}

function postrun()
{
    cd ${LOG_DIR_PATH}/../
    res_dir="$(basename ${LOG_DIR_PATH})"
    tar -zcvf ${res_dir}.tar.gz ${res_dir} &>/dev/null
    log INFO "collect info is save to: ${LOG_DIR_PATH}.tar.gz"
    if [ "$post_biostools_flag" -ne 0 ]; then
        rpm -e $(rpm -qa |grep BIOSTools|sed -n '1p') &>/dev/null
    fi
    rm -rf /tmp/LoadCollectBin* /tmp/BIOSTools/
}


function main()
{
    prerun $@
    run $@
    postrun $@
}

main $@
