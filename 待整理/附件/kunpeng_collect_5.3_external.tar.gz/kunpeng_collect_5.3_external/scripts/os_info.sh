#!/bin/bash

path="$(realpath $1)"


sysctl -a &> ${path}/sysctl_info.txt

# OS Info
echo > ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "kernel version" &>> ${path}/OS_info.txt
uname -a &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "os version" &>> ${path}/OS_info.txt
cat /etc/*release &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "kernel pagesize" &>> ${path}/OS_info.txt
echo "$(getconf PAGESIZE) kb"  &>> ${path}/OS_info.txt
printf "###########################  %20s  ###########################\n" "gcc version" &>> ${path}/OS_info.txt
which gcc &>> ${path}/OS_info.txt
gcc -v  &>> ${path}/OS_info.txt
rpm -qa |grep gcc &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "glibc version" &>> ${path}/OS_info.txt
ldd --version  &>> ${path}/OS_info.txt
rpm -qa |grep glibc &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "java version" &>> ${path}/OS_info.txt
which java  &>> ${path}/OS_info.txt
java -version  &>> ${path}/OS_info.txt
rpm -qa |grep java &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "env info" &>> ${path}/OS_info.txt
env  &>> ${path}/OS_info.txt
printf "\n###########################  %s  ###########################\n" "cmdline info" &>> ${path}/OS_info.txt
cat /proc/cmdline &>> ${path}/OS_info.txt


# CPU Info
echo > ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "lscpu" &>> ${path}/CPU_info.txt
lscpu &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "Cache Info" &>> ${path}/CPU_info.txt
cat /sys/devices/system/cpu/cpu0/cache/index0/size|awk '{printf("%-10s : %-15s\n", "L1D Cache: ",$1)}' &>> ${path}/CPU_info.txt
cat /sys/devices/system/cpu/cpu0/cache/index1/size|awk '{printf("%-10s : %-15s\n", "L1I Cache: ",$1)}' &>> ${path}/CPU_info.txt
cat /sys/devices/system/cpu/cpu0/cache/index2/size|awk '{printf("%-10s : %-15s\n", "L2  Cache: ",$1)}' &>> ${path}/CPU_info.txt
cat /sys/devices/system/cpu/cpu0/cache/index3/size|awk '{printf("%-10s : %-15s\n", "L3  Cache: ",$1)}' &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "CPU kernel paramters" &>> ${path}/CPU_info.txt
sysctl -a|grep -E "kernel.sc|cluster"|grep -v domain|awk -F '=' '{printf("%-40s : %-10s\n", $1, $2)}' &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "sched_features" &>> ${path}/CPU_info.txt
cat /sys/kernel/debug/sched_features|sed 's! !\n!g' &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "dmidecode -t processor" &>> ${path}/CPU_info.txt
dmidecode -t processor &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "dmidecode -t 7" &>> ${path}/CPU_info.txt
dmidecode -t cache &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "turbostat -d  -i 1 -n 1" &>> ${path}/CPU_info.txt
turbostat -d  -i 1 -n 1 &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "cpupower -c 0-$(($(nproc --all) - 1)) frequency-info" &>> ${path}/CPU_info.txt
cpupower -c 0-$(($(nproc --all) - 1)) frequency-info &>> ${path}/CPU_info.txt
printf "\n###########################  %s  ###########################\n" "cat /proc/cpuinfo" &>> ${path}/CPU_info.txt
cat /proc/cpuinfo &>> ${path}/CPU_info.txt

# Mem Info
echo > ${path}/Memory_info.txt
printf "\n###########################  %s  ###########################\n" "free -h" &>> ${path}/Memory_info.txt
free -h &>> ${path}/Memory_info.txt
printf "\n###########################  %s  ###########################\n" "cat /proc/meminfo" &>> ${path}/Memory_info.txt
cat /proc/meminfo &>> ${path}/Memory_info.txt
printf "\n###########################  %s  ###########################\n" "mem kernel paramters" &>> ${path}/Memory_info.txt
sysctl -a|grep -E "vm.d|vm.vfs_cache_pressure|numa|min_free_kbytes|vm.swappiness|vm.zone_reclaim_mode" |awk -F '=' '{printf("%-50s : %-10s\n", $1, $2)}' &>> ${path}/Memory_info.txt
printf "\n###########################  %s  ###########################\n" "Transparent Huge Pages" &>> ${path}/Memory_info.txt
for t in $(find /sys/kernel/mm/transparent_hugepage/  -type f);do printf "%-70s : %-10s\n" "$t" "$(cat $t)" &>> ${path}/Memory_info.txt ; done
printf "\n###########################  %s  ###########################\n" "Huge Pages" &>> ${path}/Memory_info.txt
sysctl -a|grep -E "nr_huge" |awk -F '=' '{printf("%-50s : %-10s\n", $1, $2)}' &>> ${path}/Memory_info.txt
for f in $(find  /sys/kernel/mm/hugepages/ -type f);do printf "%-70s : %-10s\n" $(echo $f) $(cat $f) &>> ${path}/Memory_info.txt ;done 
#printf "\n###########################  %s  ###########################\n" "numastat -cnmsv" &>> ${path}/Memory_info.txt
#numastat_$(uname -m) -cnmsv &>> ${path}/Memory_info.txt
printf "\n###########################  %s  ###########################\n" "dmidecode -t memory" &>> ${path}/Memory_info.txt
dmidecode -t memory &>> ${path}/Memory_info.txt


# Disk Info
echo > ${path}/Disk_info.txt
printf "\n###########################  %s  ###########################\n" "df -Tha" &>> ${path}/Disk_info.txt
df -Tha &>> ${path}/Disk_info.txt
printf "\n###########################  %s  ###########################\n" "lsblk -stf" &>> ${path}/Disk_info.txt
lsblk -atSf &>> ${path}/Disk_info.txt
printf "\n###########################  %s  ###########################\n" "mount" &>> ${path}/Disk_info.txt
mount &>> ${path}/Disk_info.txt
printf "\n###########################  %s  ###########################\n" "lsscsi" &>> ${path}/Disk_info.txt
lsscsi &>> ${path}/Disk_info.txt
for disk in $(lsblk -S|awk '{print $1}' |grep -v NAME); do
        printf "\n###########################  %s  ###########################\n" "$disk " &>> ${path}/Disk_info.txt
        for t in $(find /sys/block/${disk}/queue -type f);do printf "%-70s : %-10s\n" "$t" "$(cat $t)" &>> ${path}/Disk_info.txt ; done
done


# Network Info
function get_bind_irq_array()
{
    local BIND_NETWORK=$1
    local network_bus="$(ethtool -i ${BIND_NETWORK} | grep bus | awk '{print $2}')"
    local BIND_NETWORK_NUMA="$(lspci -vvv -s ${network_bus} | grep -i numa | awk '{print $NF}')"
    local grep_dest_re="${network_bus}|${BIND_NETWORK}"
    if dmesg|grep renamed |grep "$network_bus" &>/dev/null ; then
        local rename="$(dmesg|grep renamed |grep "$network_bus"|awk '{print $NF}')"
        grep_dest_re="${grep_dest_re}|${rename}"
    fi
    local grep_except_re="mlx5_pages_eq|mlx5_cmd_eq|mlx5_async|hclge-misc"
    printf "NUMA: $BIND_NETWORK_NUMA \n" &>> ${path}/Network_info.txt
    for irq in $(cat /proc/interrupts| grep -E "$grep_dest_re" | grep -vE "$grep_except_re" | awk -F ':' '{print $1}'); do
        printf "irq: $irq -> cpu: `cat /proc/irq/${irq}/smp_affinity_list` \n" &>> ${path}/Network_info.txt
    done
    printf "\n" &>> ${path}/Network_info.txt
}

echo > ${path}/Network_info.txt
printf "\n###########################  %s  ###########################\n" "ip a" &>> ${path}/Network_info.txt
ip a &>> ${path}/Network_info.txt

for net in $(cat /proc/net/dev|grep ^[eb]|awk '{print $1}'|tr -d ":"); do
        printf "\n###########################  %s  ###########################\n" "${net}" &>> ${path}/Network_info.txt
		printf "\n--------------------------- irq and NUMA -----------------------------\n" &>> ${path}/Network_info.txt
        get_bind_irq_array ${net}
		printf "\n--------------------------- ethtool -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- ethtool -g -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool -g ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- ethtool -c -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool -c ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- ethtool -l -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool -l ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- ethtool -k -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool -k ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- ethtool -i -----------------------------\n" &>> ${path}/Network_info.txt
        ethtool -i ${net} &>> ${path}/Network_info.txt
		printf "\n--------------------------- net driver -----------------------------\n" &>> ${path}/Network_info.txt
		modinfo $(ethtool -i enp125s0f0|grep driver|awk '{print $NF}')  &>> ${path}/Network_info.txt
		printf "\n--------------------------- net lspci -----------------------------\n" &>> ${path}/Network_info.txt
        lspci -vvv -s $(ethtool -i ${net} | grep bus | awk '{print $2}') &>> ${path}/Network_info.txt
done


# PCIe Info
echo > ${path}/PCIe_info.txt
lspci &>> ${path}/PCIe_info.txt
lspci -vvv &>> ${path}/PCIe_info.txt

# Dmidecode
echo > ${path}/Dmidecode_info.txt
dmidecode &>> ${path}/Dmidecode_info.txt
