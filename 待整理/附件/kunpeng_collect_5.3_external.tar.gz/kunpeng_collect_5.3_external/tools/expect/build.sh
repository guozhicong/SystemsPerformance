#!/bin/bash

cd $(dirname $0)

tar zxvf tcl8.4.20-src.tar.gz

cd tcl8.4.20/unix/

./configure --prefix=$(pwd)/../../../../  --enable-shared

make -j4

make install

cd ..

echo y | cp unix/tclUnixPort.h generic/.

cd ..

tar zxvf expect5.45.tar.gz

cd expect5.45

if [ "$(uname -m)" = "aarch64" ] ; then
    ./configure --prefix=$(pwd)/../../../ --with-tcl=$(pwd)/../../../lib --with-tclinclude=../tcl8.4.20/generic/ --build=arm
elif [ "$(uname -m)" = "x86_64" ] ; then
    ./configure --prefix=$(pwd)/../../../ --with-tcl=$(pwd)/../../../lib --with-tclinclude=../tcl8.4.20/generic/ 
fi

make -j4

make install

cd ..
