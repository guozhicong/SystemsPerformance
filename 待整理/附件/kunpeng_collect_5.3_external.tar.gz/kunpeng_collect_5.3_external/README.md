Usage:
 collect.sh -t [collect times] -p [pid]

Options:
 -p              example: pid1,pid2
 -t              collect seconds, default 5
 -k              result dir keywords
 -d              set collecting conf file or some dirs, default
 -K              set process keywords, default , input multi with ":"
 -s              set collect type, default: all, support {basic_and_perf_info |micro_info | hardware_info| os_info | nmon_info}, input multi with ":"
 -v              show version info
 -h              show help info

 Example1:       bash collect.sh -t 5 -p $(pidof mysql)
 Example2:       bash collect.sh -t 5 -k test -p $(pidof observer),$(pidof obproxy)
 Example3:       bash collect.sh -t 5 -d /etc/profile:/etc/sysctl.conf:/etc/my.cnf
 Example4:       bash collect.sh -t 5 -K observer:obproxy -s basic_info:nmon_info:os_info


# bash ./collect.sh -t 10  # 抓取10秒中负载情况

# 2024-03-15 15:25:23 [INFO]: collect info is save to: /opt/kunpeng_collect/results/2024-03-15-15-23-46.tar.gz
如上是打包的结果文件

#V5.2
增加指定不同收集类型和进程关键字

#V5.0
增加nmon抓取并自动转化为html图形化

#V3.5
1、BIOS收集工具优化，解决部分获取失败问题
2、支持鲲鹏920
3、支持-k 参数指定结果文件的关键字，用于区分不同场景需要


#V3.4
增加多个pid的传入，和结果文件夹通过-k 指定关键字区别

